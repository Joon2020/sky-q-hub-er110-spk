#!/bin/sh

OBJ=$1
BASENAME=`basename ${OBJ}`
DIRNAME=`dirname ${OBJ}`
MODNAME=`echo ${BASENAME} | sed -ne "s/\(.*\)\.o/\1/p"`

rm -rf modbuilddir
mkdir -p modbuilddir

cat > modbuilddir/Makefile << _EOF
obj-m := ${MODNAME}.o
${MODNAME}-objs := ${MODNAME}.o_save
_EOF

cp -a ${OBJ} modbuilddir/${MODNAME}.o_save

make -C ${KDIR} SUBDIRS=`pwd`/modbuilddir modules

mv modbuilddir/${MODNAME}.ko ${DIRNAME}/
rm -rf modbuilddir ${OBJ}
